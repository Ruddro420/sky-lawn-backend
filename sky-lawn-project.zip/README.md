Database Table:
Room -> RoomModel -model:migration
     -> RoomCategory -model:migration


     Room category : /api/room-category 
     
            format=>    {
                            "id": 1,
                            "name": "delux",
                            "created_at": null,
                            "updated_at": null
                        } 